1. Open command line in project folder
2. Run 'npm i' in command line
3. Run 'node bigCommerceImport.js' to start import